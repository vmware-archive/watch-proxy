package v1alpha3

// VirtualServiceListerExpansion allows custom methods to be added to
// VirtualServiceLister.
type VirtualServiceListerExpansion interface{}

// VirtualServiceNamespaceListerExpansion allows custom methods to be added to
// VirtualServiceNamespaceLister.
type VirtualServiceNamespaceListerExpansion interface{}
