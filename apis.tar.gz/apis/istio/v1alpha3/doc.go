// +k8s:deepcopy-gen=package
// +groupName=networking.istio.io
package v1alpha3
